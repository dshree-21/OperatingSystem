#include "types.h"
#include "stat.h"
#include "user.h"
int main()
{
  printf(1,"Ppid is:%d\nPid is:%d\n",getppid(),getpid());
  exit();
}




