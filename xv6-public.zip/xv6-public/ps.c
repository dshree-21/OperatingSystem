#include "types.h"
#include "stat.h"
#include "user.h"
int main(int argc,char **argv)
{
   
   sps();
   printf(1,"\n\nMy Roll no.is: 20051139\n\n");
   exit();
  }
